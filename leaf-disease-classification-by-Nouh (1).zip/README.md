# Leaf Disease Classifier 🌿 - By Nouh

This project classifies plant leaves as **healthy** or **diseased** using deep learning with MobileNetV2.

## 📁 Dataset Structure

```
dataset/
├── train/
│   ├── healthy/
│   └── diseased/
└── val/
    ├── healthy/
    └── diseased/
```

## ▶️ How to Run

```bash
pip install -r requirements.txt
python leaf_classifier.py
```

## 🧪 Model

- Pretrained: MobileNetV2
- Loss Function: Binary Crossentropy
- Optimizer: Adam